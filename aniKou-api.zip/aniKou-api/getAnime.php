<?php
require 'config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$sql = "SELECT a.id, a.tmdbId, a.name, a.overview, a.adult, a.backdrop_path, a.episode_run_time, a.first_air_date, 
               a.genres, a.homepage, a.origin_country, a.original_language, a.original_name, a.popularity, a.poster_path,
               a.production_companies, a.seasons, a.status, a.vote_average, a.vote_count, a.created_at, a.updated_at
        FROM animes a";

$conditions = [];
$params = [];
$types = "";

if (!empty($data['id'])) {
    $conditions[] = "a.id = ?";
    $params[] = $data['id'];
    $types .= "i";
}

if (!empty($data['tmdbId'])) {
    $conditions[] = "a.tmdbId = ?";
    $params[] = $data['tmdbId'];
    $types .= "s";
}

if (!empty($data['media_type'])) {
    $conditions[] = "a.media_type = ?";
    $params[] = $data['media_type'];
    $types .= "s";
}

if (!empty($data['name'])) {
    $conditions[] = "a.name LIKE ?";
    $params[] = "%" . $data['name'] . "%";
    $types .= "s";
}

if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

if (!empty($data['sortBy'])) {
    switch ($data['sortBy']) {
        case 'popular':
            $sql .= " ORDER BY a.popularity DESC";
            break;
        case 'favorite':
            $sql .= " ORDER BY a.vote_count DESC";
            break;
        case 'rated':
            $sql .= " ORDER BY a.vote_average DESC";
            break;
        default:
            $sql .= " ORDER BY a.id ASC";
            break;
    }
} else {
    $sql .= " ORDER BY a.id ASC";
}

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["error" => "Error preparing statement: " . $conn->error]);
    exit;
}

if (count($params) > 0) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$animes = [];
while ($row = $result->fetch_assoc()) {
    $anime = [
        'anime' => [
            'id' => $row['id'] ?? null,
            'tmdbId' => $row['tmdbId'] ?? null,
            'name' => $row['name'] ?? null,
            'overview' => $row['overview'] ?? null,
            'adult' => $row['adult'] ?? null,
            'backdrop_path' => $row['backdrop_path'] ?? null,
            'episode_run_time' => $row['episode_run_time'] ?? null,
            'first_air_date' => $row['first_air_date'] ?? null,
            'genres' => isset($row['genres']) ? json_decode($row['genres']) : null,
            'homepage' => $row['homepage'] ?? null,
            'origin_country' => isset($row['origin_country']) ? json_decode($row['origin_country']) : null,
            'original_language' => $row['original_language'] ?? null,
            'original_name' => $row['original_name'] ?? null,
            'popularity' => $row['popularity'] ?? null,
            'poster_path' => $row['poster_path'] ?? null,
            'production_companies' => isset($row['production_companies']) ? json_decode($row['production_companies']) : null,
            'seasons' => isset($row['seasons']) ? json_decode($row['seasons']) : null,
            'status' => $row['status'] ?? null,
            'vote_average' => $row['vote_average'] ?? null,
            'vote_count' => $row['vote_count'] ?? null,
            'created_at' => $row['created_at'] ?? null,
            'updated_at' => $row['updated_at'] ?? null,
        ],
        'videos' => [],
        'images' => [],
        'casts' => []
    ];

    $animes[] = $anime;
}

$stmt->close();

$animeIds = array_map(function($anime) { return $anime['anime']['id']; }, $animes);

$sql_videos = "SELECT v.animeId, v.id AS video_id, v.name AS video_name, v.key AS video_key, v.site AS video_site, v.type AS video_type
               FROM videos v WHERE v.animeId IN (" . implode(',', array_fill(0, count($animeIds), '?')) . ")";
$stmt_videos = $conn->prepare($sql_videos);
$stmt_videos->bind_param(str_repeat('i', count($animeIds)), ...$animeIds);
$stmt_videos->execute();
$videos = $stmt_videos->get_result();

while ($video = $videos->fetch_assoc()) {
    foreach ($animes as &$anime) {
        if ($anime['anime']['id'] == $video['animeId']) {
            $anime['videos'][] = [
                'id' => $video['video_id'],
                'key' => $video['video_key'],
                'site' => $video['video_site'],
                'type' => $video['video_type'],
                'name' => $video['video_name'],
            ];
        }
    }
}

$stmt_videos->close();

$sql_images = "SELECT i.animeId, i.id AS image_id, i.file_path AS image_file_path, i.vote_average AS image_vote_average
               FROM images i WHERE i.animeId IN (" . implode(',', array_fill(0, count($animeIds), '?')) . ")";
$stmt_images = $conn->prepare($sql_images);
$stmt_images->bind_param(str_repeat('i', count($animeIds)), ...$animeIds);
$stmt_images->execute();
$images = $stmt_images->get_result();

while ($image = $images->fetch_assoc()) {
    foreach ($animes as &$anime) {
        if ($anime['anime']['id'] == $image['animeId']) {
            $anime['images'][] = [
                'image_id' => $image['image_id'],
                'file_path' => $image['image_file_path'],
                'vote_average' => $image['image_vote_average'],
            ];
        }
    }
}

$stmt_images->close();

$sql_casts = "SELECT c.animeId, c.id AS cast_id, c.characterName AS cast_characterName, c.name AS cast_name, c.profile_path AS cast_profile_path
              FROM casts c WHERE c.animeId IN (" . implode(',', array_fill(0, count($animeIds), '?')) . ")";
$stmt_casts = $conn->prepare($sql_casts);
$stmt_casts->bind_param(str_repeat('i', count($animeIds)), ...$animeIds);
$stmt_casts->execute();
$casts = $stmt_casts->get_result();

while ($cast = $casts->fetch_assoc()) {
    foreach ($animes as &$anime) {
        if ($anime['anime']['id'] == $cast['animeId']) {
            $anime['casts'][] = [
                'cast_id' => $cast['cast_id'],
                'characterName' => $cast['cast_characterName'],
                'name' => $cast['cast_name'],
                'profile_path' => $cast['cast_profile_path'],
            ];
        }
    }
}

$stmt_casts->close();
$conn->close();

if (count($animes) > 0) {
    echo json_encode(["success" => true, "data" => $animes]);
} else {
    echo json_encode(["success" => false, "message" => "No animes found."]);
}

?>
