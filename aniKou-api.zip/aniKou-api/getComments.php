<?php
require 'config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['animeId'])) {
    echo json_encode(["error" => "animeId is required"]);
    exit;
}

$sql = "SELECT c.id, c.name, c.userId, c.pfp, c.comment, c.created_at
        FROM comments c
        WHERE c.animeId = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["error" => "Error preparing statement: " . $conn->error]);
    exit;
}

$stmt->bind_param("i", $data['animeId']);
$stmt->execute();
$result = $stmt->get_result();

$comments = [];

while ($row = $result->fetch_assoc()) {
    $comments[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'userId' => $row['userId'],
        'pfp' => $row['pfp'],
        'comment' => $row['comment'],
        'created_at' => $row['created_at']
    ];
}

if (count($comments) > 0) {
    echo json_encode(["success" => true, "data" => $comments]);
} else {
    echo json_encode(["success" => false, "message" => "No comments found for this anime."]);
}

$stmt->close();
$conn->close();
?>
