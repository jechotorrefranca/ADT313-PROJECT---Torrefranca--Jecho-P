<?php
require 'config.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;

$headers = getallheaders();
$accessToken = $headers['authorization'] ?? '';

try {
    if (strpos($accessToken, 'Bearer ') === 0) {
        $accessToken = substr($accessToken, 7);
    }
    $key = new Key($secretKey, 'HS256');
    $decoded = JWT::decode($accessToken, $key);
    if (!isset($decoded->data->user_id) || !isset($decoded->data->user_email) || !isset($decoded->data->user_role)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid token structure.']);
        exit;
    }

    if ($decoded->data->user_role !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Access denied.']);
        exit;
    }
} catch (ExpiredException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Access token has expired.']);
    exit;
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid access token.',
        'error' => $e->getMessage(),
        'headers' => $headers,
        'accessToken' => $accessToken
    ]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$isAdmin = ($decoded->data->user_role === 'admin');

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $decoded->data->user_id;

    $tmdbId = $data['tmdbId'];
    $adult = $data['adult'];
    $backdrop_path = $data['backdrop_path'];
    $episode_run_time = $data['episode_run_time'];
    $first_air_date = $data['first_air_date'];
    $genres = json_encode($data['genres']);
    $homepage = $data['homepage'];
    $origin_country = json_encode($data['origin_country']);
    $original_language = $data['original_language'];
    $original_name = $data['original_name'];
    $name = $data['name'];
    $overview = $data['overview'];
    $popularity = $data['popularity'];
    $poster_path = $data['poster_path'];
    $production_companies = json_encode($data['production_companies']);
    $seasons = json_encode($data['seasons']);
    $status = $data['status'];
    $vote_average = $data['vote_average'];
    $vote_count = $data['vote_count'];

    $stmt = $conn->prepare("
        INSERT INTO animes 
        (userId, tmdbId, adult, backdrop_path, episode_run_time, first_air_date, genres, homepage, origin_country, 
        original_language, original_name, name, overview, popularity, poster_path, production_companies, seasons, 
        status, vote_average, vote_count) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param(
        "iiissssssssssdssssdi", 
        $userId, $tmdbId, $adult, $backdrop_path, $episode_run_time, $first_air_date, $genres, $homepage, 
        $origin_country, $original_language, $original_name, $name, $overview, $popularity, $poster_path, 
        $production_companies, $seasons, $status, $vote_average, $vote_count
    );

    if ($stmt->execute()) {
        echo json_encode(["success" => "Anime added successfully", "id" => $conn->insert_id]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
    
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $id = $data['id'];
    
    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'Missing id for update.']);
        exit;
    }

    $fields = [];
    $params = [];
    $types = '';

    foreach ($data as $key => $value) {
        if ($key !== 'id') {
            $fields[] = "$key = ?";
            $params[] = $value;
            $types .= is_int($value) ? 'i' : (is_float($value) ? 'd' : 's');
        }
    }

    $params[] = $id;
    $types .= 'i';

    $sql = "UPDATE animes SET " . implode(", ", $fields) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid query.']);
        exit;
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Anime updated successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $data['id'];

    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'Missing id for deletion.']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM animes WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Anime deleted successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}


$conn->close();
?>
