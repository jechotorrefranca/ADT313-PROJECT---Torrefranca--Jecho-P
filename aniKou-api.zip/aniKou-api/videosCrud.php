<?php
require 'config.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;

$headers = getallheaders();
$accessToken = $headers['authorization'] ?? '';

try {
    if (strpos($accessToken, 'Bearer ') === 0) {
        $accessToken = substr($accessToken, 7);
    }
    $key = new Key($secretKey, 'HS256');
    $decoded = JWT::decode($accessToken, $key);
    if (!isset($decoded->data->user_id) || !isset($decoded->data->user_email) || !isset($decoded->data->user_role)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid token structure.']);
        exit;
    }

    if ($decoded->data->user_role !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Access denied.']);
        exit;
    }
} catch (ExpiredException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Access token has expired.']);
    exit;
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid access token.',
        'error' => $e->getMessage(),
        'headers' => $headers,
        'accessToken' => $accessToken
    ]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$isAdmin = ($decoded->data->user_role === 'admin');

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $data['key'];
    $name = $data['name'];
    $site = $data['site'];
    $type = $data['type'];
    $animeId = $data['animeId'];

    $stmt = $conn->prepare("
        INSERT INTO videos 
        (`key`, name, site, type, animeId) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "ssssi",
        $key, $name, $site, $type, $animeId
    );

    if ($stmt->execute()) {
        echo json_encode(["success" => "Video added successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $id = $data['id'];

    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'Missing id for update.']);
        exit;
    }

    $fields = [];
    $params = [];
    $types = '';

    foreach ($data as $key => $value) {
        if ($key !== 'id') {
            $fields[] = ($key === 'key' ? "`$key`" : "$key") . " = ?";
            $params[] = $value;
            $types .= is_int($value) ? 'i' : (is_float($value) ? 'd' : 's');
        }
    }

    $params[] = $id;
    $types .= 'i';

    $sql = "UPDATE videos SET " . implode(", ", $fields) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid query.']);
        exit;
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Video updated successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}


if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $data['id'];

    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'Missing id for deletion.']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM videos WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Video deleted successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

$conn->close();
?>
