<?php
require 'config.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;

$headers = getallheaders();
$accessToken = $headers['authorization'] ?? '';

try {
    if (strpos($accessToken, 'Bearer ') === 0) {
        $accessToken = substr($accessToken, 7);
    }
    $key = new Key($secretKey, 'HS256');
    $decoded = JWT::decode($accessToken, $key);

    if (!isset($decoded->data->user_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid token structure.']);
        exit;
    }

} catch (ExpiredException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Access token has expired.']);
    exit;
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid access token.',
        'error' => $e->getMessage(),
        'headers' => $headers,
        'accessToken' => $accessToken
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $comment = $data['comment_text'] ?? null;
    $animeId = $data['anime_id'] ?? null;
    $userId = $data['user_id'] ?? null;
    $name = $data['user_name'] ?? null;
    $pfp = $data['pfp'] ?? 'https://via.placeholder.com/50';

    if (!$comment || !$animeId || !$userId || !$name) {
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO comments 
        (name, animeId, userId, pfp, comment) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("siiss", $name, $animeId, $userId, $pfp, $comment);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Comment added successfully"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

$conn->close();
?>
