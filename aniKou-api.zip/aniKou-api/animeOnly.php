<?php
require 'config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$sql = "SELECT a.* 
        FROM animes a";

$conditions = [];
$params = [];
$types = "";

if (!empty($data['id'])) {
    $conditions[] = "a.id = ?";
    $params[] = $data['id'];
    $types .= "i";
}

if (!empty($data['tmdbId'])) {
    $conditions[] = "a.tmdbId = ?";
    $params[] = $data['tmdbId'];
    $types .= "s";
}

if (!empty($data['media_type'])) {
    $conditions[] = "a.media_type = ?";
    $params[] = $data['media_type'];
    $types .= "s";
}

if (!empty($data['name'])) {
    $conditions[] = "a.name LIKE ?";
    $params[] = "%" . $data['name'] . "%";
    $types .= "s";
}

if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

if (!empty($data['sortBy'])) {
    switch ($data['sortBy']) {
        case 'popular':
            $sql .= " ORDER BY a.popularity DESC";
            break;
        case 'favorite':
            $sql .= " ORDER BY a.vote_count DESC";
            break;
        case 'rated':
            $sql .= " ORDER BY a.vote_average DESC";
            break;
        default:
            $sql .= " ORDER BY a.id ASC";
            break;
    }
} else {
    $sql .= " ORDER BY a.id ASC";
}

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["error" => "Error preparing statement: " . $conn->error]);
    exit;
}

if (count($params) > 0) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$animes = [];

while ($row = $result->fetch_assoc()) {
    $anime = [
        'anime' => [
            'id' => $row['id'] ?? null,
            'tmdbId' => $row['tmdbId'] ?? null,
            'name' => $row['name'] ?? null,
            'overview' => $row['overview'] ?? null,
            'adult' => $row['adult'] ?? null,
            'backdrop_path' => $row['backdrop_path'] ?? null,
            'episode_run_time' => $row['episode_run_time'] ?? null,
            'first_air_date' => $row['first_air_date'] ?? null,
            'genres' => isset($row['genres']) ? json_decode($row['genres']) : null,
            'homepage' => $row['homepage'] ?? null,
            'origin_country' => isset($row['origin_country']) ? json_decode($row['origin_country']) : null,
            'original_language' => $row['original_language'] ?? null,
            'original_name' => $row['original_name'] ?? null,
            'popularity' => $row['popularity'] ?? null,
            'poster_path' => $row['poster_path'] ?? null,
            'production_companies' => isset($row['production_companies']) ? json_decode($row['production_companies']) : null,
            'seasons' => isset($row['seasons']) ? json_decode($row['seasons']) : null,
            'status' => $row['status'] ?? null,
            'vote_average' => $row['vote_average'] ?? null,
            'vote_count' => $row['vote_count'] ?? null,
            'created_at' => $row['created_at'] ?? null,
            'updated_at' => $row['updated_at'] ?? null,
        ]
    ];

    $animes[] = $anime;
}

if (count($animes) > 0) {
    echo json_encode(["success" => true, "data" => $animes]);
} else {
    echo json_encode(["success" => false, "message" => "No animes found."]);
}

$stmt->close();
$conn->close();
?>
