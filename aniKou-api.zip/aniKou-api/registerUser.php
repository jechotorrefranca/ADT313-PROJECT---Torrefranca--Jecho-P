<?php
require 'config.php';

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Validate required fields
$requiredFields = ['email', 'password', 'firstName', 'lastName', 'middleName', 'contactNo'];
foreach ($requiredFields as $field) {
    if (empty($data[$field])) {
        echo json_encode(["error" => "$field is required."]);
        exit;
    }
}

// Sanitize inputs and hash the password using md5
$email = $data['email'];
$password = md5($data['password']); // Hash password with md5 (insecure, not recommended)
$firstName = $data['firstName'];
$lastName = $data['lastName'];
$middleName = $data['middleName'];
$contactNo = $data['contactNo'];
$role = 'user';

// Prepare the SQL statement
$stmt = $conn->prepare("
    INSERT INTO users (email, password, firstName, lastName, middleName, contactNo, role) 
    VALUES (?, ?, ?, ?, ?, ?, ?)
");

// Bind parameters
$stmt->bind_param(
    "sssssss",
    $email,
    $password,
    $firstName,
    $lastName,
    $middleName,
    $contactNo,
    $role
);

// Execute the prepared statement and handle the result
if (!$stmt) {
    echo json_encode(["error" => "Error preparing statement: " . $conn->error]);
    exit;
}

if ($stmt->execute()) {
    echo json_encode(["success" => "User registered successfully"]);
} else {
    echo json_encode(["error" => "Error executing query: " . $stmt->error]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
